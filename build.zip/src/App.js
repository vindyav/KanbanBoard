import logo from './logo.svg';
import './App.css';
import KanbanBoard from './components/KanbanBoard'
function App() {
  return (
    <div className="App">
      <KanbanBoard />
    </div>
  );
}

export default App;
